![[LCS LOGO.jpg]]

---

# Inhaltsangabe

- Was ist LCS
- Warum LCS
- Planung
- Erste Version mit Java
- Probleme mit Java
- Erste Version mit Lua
- Letzte Abgabe
- Wo wir heute stehen
- Zukunftsaussicht
- Was wir hätten besser machen können

---

<center> <p style="font-size: 150px;">L.C.S.</p> 
<p style="font-size: 80px;">Logic Circuit Simulator</p> </center>

---

# Digitalsimulator

![[Pasted image 20230614195913.png]]

---

# Planung

![[Trello Board.png]]

---

# Java Version

### Features

* Mehrere Boards
* Menü mit Einstellungen
* Panning
* Angenehmes Design

---

# Java Version

### Probleme

* Keine funktionierende Logik
* Kein Speichern und Laden von Boards
* Komplizierte Klassenhierachie
* GUI Library ist nicht für große und vielschichtige Apps gedacht

---

# Entdeckung von Lua

- Schnelle, einfache Scripting Programmiersprache
- Love2D Game-Engine-Framework für OpenGL Fenster
- Einfache Darstellung von simplen Grafiken

---

# Erste Lua Version

![[LCS v.1.png]]

---

## Features
- Funktionierende Logik
- Grundlegende Gatter
- Simple Grafik

---

## Probleme
- Einige Bugs
- Nur ein Board
- Kein Menü, keine Einstellungen
- Kein Speichern und Laden


---

# Zweite Lua Version

![[LCS v.2.png]]

---

## Features
- Funktionierende Logik
- Gatter, Clocks und Puffer
- Simple GUI Elemente
- Verschiedene Boards mit Speichern und Laden
- Copy & Paste
- Plotter

---

## Probleme
- Kein Menü
- Keine Auswahl
- Viele Bugs

---

# Dritte Lua Version

![[Pasted image 20230613210302.png]]

---

## Features
- Funktionierende Logik
- Gatter, Clocks und Puffer
- Simple GUI Elemente
- Verschiedene Boards mit Speichern und Laden
- Copy & Paste
- Plotter
- Vollständiges Menü
- Simple Einstellungen

---

## Probleme
- Wenige Bugs
- Kein "Inboard Copy & Paste"
- Restliche Geplante Features
	- Multithreading
	- ICs % Scriptable ICs
	- Undo/Redo System

---

# Die Zukunft von LCS

- Programm neu schreiben um Multithreading und ICs zu ermöglichen
- Als vollständiges Programm an Schulen verkaufen